﻿/// <reference path="carro.ts" />

function MostarCarro() {
    let novoCarrro = new Carro("BMW");
    document.getElementById("divmensagem").innerHTML = novoCarrro.CriarNomeCarro();// DOM


    let novoCarro2 = new Carro("Mercedes");
    $("#divmensagem2").html(novoCarro2.CriarNomeCarro()); // Jquery


    let novoTrator = new Trator("Trator 5000");// Herança de Objeto
    novoTrator.peso = 100000;
    $("#divmensagem3").html(novoTrator.CriarNomeCarro() + " " + novoTrator.peso.toString());

}