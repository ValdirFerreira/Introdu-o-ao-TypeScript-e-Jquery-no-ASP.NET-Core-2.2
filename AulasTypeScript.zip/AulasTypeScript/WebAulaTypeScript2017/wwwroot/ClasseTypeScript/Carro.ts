﻿class Carro {
    private nome: string;

    constructor(nomeCarro: string) {
        this.nome = nomeCarro;
    }

    public CriarNomeCarro(): string {
        return "Seu carro e :" + this.nome;
    }

}

enum TipoCarro {
    CarroPasseio = 1,
    Caminhão = 2,
    Trator = 3
}


class Trator extends Carro {

    peso: number;
}